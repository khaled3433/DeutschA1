package com.example.deutscha1

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlinx.coroutines.delay

data class Word(val german: String, val arabic: String, val category: String)

private val words = listOf(
    Word("Hallo", "مرحبًا", "التحيات"),
    Word("Guten Morgen", "صباح الخير", "التحيات"),
    Word("Guten Tag", "نهارك سعيد", "التحيات"),
    Word("Guten Abend", "مساء الخير", "التحيات"),
    Word("Tschüss", "وداعًا", "التحيات"),
    Word("Bitte", "من فضلك / عفوًا", "العبارات الأساسية"),
    Word("Danke", "شكرًا", "العبارات الأساسية"),
    Word("Ja", "نعم", "العبارات الأساسية"),
    Word("Nein", "لا", "العبارات الأساسية"),
    Word("Entschuldigung", "عذرًا", "العبارات الأساسية"),
    Word("Ich", "أنا", "الضمائر"),
    Word("Du", "أنت", "الضمائر"),
    Word("Er", "هو", "الضمائر"),
    Word("Sie", "هي / حضرتك / هم", "الضمائر"),
    Word("Wir", "نحن", "الضمائر"),
    Word("Ihr", "أنتم", "الضمائر"),
    Word("sein", "يكون", "أفعال أساسية"),
    Word("haben", "يملك / لديه", "أفعال أساسية"),
    Word("machen", "يفعل / يصنع", "أفعال أساسية"),
    Word("gehen", "يذهب", "أفعال أساسية"),
    Word("kommen", "يأتي", "أفعال أساسية"),
    Word("wohnen", "يسكن", "أفعال أساسية"),
    Word("lernen", "يتعلم", "أفعال أساسية"),
    Word("sprechen", "يتحدث", "أفعال أساسية"),
    Word("essen", "يأكل", "أفعال أساسية"),
    Word("trinken", "يشرب", "أفعال أساسية"),
    Word("das Haus", "البيت", "المنزل"),
    Word("die Wohnung", "الشقة", "المنزل"),
    Word("das Zimmer", "الغرفة", "المنزل"),
    Word("die Küche", "المطبخ", "المنزل"),
    Word("die Schule", "المدرسة", "الدراسة"),
    Word("der Lehrer", "المعلم", "الدراسة"),
    Word("die Lehrerin", "المعلمة", "الدراسة"),
    Word("das Buch", "الكتاب", "الدراسة"),
    Word("der Stift", "القلم", "الدراسة"),
    Word("die Arbeit", "العمل", "العمل"),
    Word("der Beruf", "المهنة", "العمل"),
    Word("der Freund", "الصديق", "الأشخاص"),
    Word("die Freundin", "الصديقة", "الأشخاص"),
    Word("die Familie", "العائلة", "الأشخاص"),
    Word("die Mutter", "الأم", "الأشخاص"),
    Word("der Vater", "الأب", "الأشخاص"),
    Word("das Kind", "الطفل", "الأشخاص"),
    Word("heute", "اليوم", "الوقت"),
    Word("morgen", "غدًا", "الوقت"),
    Word("gestern", "أمس", "الوقت"),
    Word("jetzt", "الآن", "الوقت"),
    Word("später", "لاحقًا", "الوقت"),
    Word("eins", "واحد", "الأرقام"),
    Word("zwei", "اثنان", "الأرقام"),
    Word("drei", "ثلاثة", "الأرقام"),
    Word("vier", "أربعة", "الأرقام"),
    Word("fünf", "خمسة", "الأرقام"),
    Word("sechs", "ستة", "الأرقام"),
    Word("sieben", "سبعة", "الأرقام"),
    Word("acht", "ثمانية", "الأرقام"),
    Word("neun", "تسعة", "الأرقام"),
    Word("zehn", "عشرة", "الأرقام"),
    Word("gut", "جيد", "صفات"),
    Word("schlecht", "سيئ", "صفات"),
    Word("groß", "كبير", "صفات"),
    Word("klein", "صغير", "صفات"),
    Word("neu", "جديد", "صفات"),
    Word("alt", "قديم / كبير في السن", "صفات"),
    Word("schnell", "سريع", "صفات"),
    Word("langsam", "بطيء", "صفات"),
    Word("warm", "دافئ", "صفات"),
    Word("kalt", "بارد", "صفات"),
    Word("Wasser", "ماء", "الطعام والشراب"),
    Word("Brot", "خبز", "الطعام والشراب"),
    Word("Milch", "حليب", "الطعام والشراب"),
    Word("Kaffee", "قهوة", "الطعام والشراب"),
    Word("Tee", "شاي", "الطعام والشراب"),
    Word("Apfel", "تفاحة", "الطعام والشراب"),
    Word("Banane", "موزة", "الطعام والشراب"),
    Word("Restaurant", "مطعم", "أماكن"),
    Word("Supermarkt", "متجر سوبرماركت", "أماكن"),
    Word("Bahnhof", "محطة قطار", "أماكن"),
    Word("Straße", "شارع", "أماكن"),
    Word("Stadt", "مدينة", "أماكن"),
    Word("links", "يسار", "الاتجاهات"),
    Word("rechts", "يمين", "الاتجاهات"),
    Word("geradeaus", "إلى الأمام", "الاتجاهات"),
    Word("wo", "أين", "كلمات السؤال"),
    Word("wer", "من", "كلمات السؤال"),
    Word("was", "ماذا", "كلمات السؤال"),
    Word("wann", "متى", "كلمات السؤال"),
    Word("warum", "لماذا", "كلمات السؤال"),
    Word("wie", "كيف", "كلمات السؤال"),
    Word("wie viel", "كم", "كلمات السؤال")
)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.GERMAN
            }
        }
        setContent { DeutschA1App { speak(it) } }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "deutsch_a1")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun DeutschA1App(onSpeak: (String) -> Unit) {
    var selectedTab by remember { mutableStateOf(0) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var interval by remember { mutableStateOf(5) }
    var autoRepeat by remember { mutableStateOf(false) }
    var currentIndex by remember { mutableStateOf(0) }

    LaunchedEffect(autoRepeat, interval) {
        while (autoRepeat) {
            delay(interval * 1000L)
            currentIndex = (currentIndex + 1) % words.size
            onSpeak(words[currentIndex].german)
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Deutsch A1 🇩🇪") })
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Text("📚") },
                        label = { Text("الكلمات") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Text("⭐") },
                        label = { Text("المراجعة") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Text("⚙️") },
                        label = { Text("الإعدادات") }
                    )
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> WordList(
                    Modifier.padding(padding),
                    words,
                    favorites,
                    { word ->
                        favorites = if (word.german in favorites)
                            favorites - word.german else favorites + word.german
                    },
                    onSpeak
                )
                1 -> WordList(
                    Modifier.padding(padding),
                    words.filter { it.german in favorites },
                    favorites,
                    { word -> favorites = favorites - word.german },
                    onSpeak,
                    emptyMessage = "لا توجد كلمات في المراجعة ⭐"
                )
                2 -> SettingsScreen(
                    Modifier.padding(padding),
                    interval,
                    { interval = it },
                    autoRepeat,
                    { autoRepeat = it }
                )
            }
        }
    }
}

@Composable
fun WordList(
    modifier: Modifier,
    list: List<Word>,
    favorites: Set<String>,
    onFavorite: (Word) -> Unit,
    onSpeak: (String) -> Unit,
    emptyMessage: String = "لا توجد كلمات."
) {
    if (list.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(emptyMessage)
        }
        return
    }

    LazyColumn(modifier.fillMaxSize().padding(12.dp)) {
        items(list, key = { it.german }) { word ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(word.german, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(4.dp))
                        Text(word.arabic)
                        Text(word.category, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = { onSpeak(word.german) }) {
                        Text("🔊")
                    }
                    IconButton(onClick = { onFavorite(word) }) {
                        Text(if (word.german in favorites) "⭐" else "☆")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    modifier: Modifier,
    interval: Int,
    onIntervalChange: (Int) -> Unit,
    autoRepeat: Boolean,
    onAutoRepeatChange: (Boolean) -> Unit
) {
    Column(modifier.padding(20.dp)) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(24.dp))

        Text("الفاصل الزمني: $interval ثوانٍ")
        Slider(
            value = interval.toFloat(),
            onValueChange = { onIntervalChange(it.toInt().coerceIn(1, 30)) },
            valueRange = 1f..30f,
            steps = 28
        )

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("التكرار التلقائي", Modifier.weight(1f))
            Switch(
                checked = autoRepeat,
                onCheckedChange = onAutoRepeatChange
            )
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "يستخدم التطبيق محرك النطق الألماني الموجود على جهازك. " +
            "يمكنك تغيير محرك النطق واللغة من إعدادات تحويل النص إلى كلام في Android."
        )
        Spacer(Modifier.height(18.dp))
        Text("عدد الكلمات: ${words.size}")
    }
}
